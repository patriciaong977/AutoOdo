package com.example.projectautoodo;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class Database extends SQLiteOpenHelper
{

    //table strings
    public static final String MILES_TABLE = "MILES_TABLE";
    public static final  String KEY_ID= "ID";
    public static final String COLUMN_MILES = "MILES";
    public static final String COLUMN_DATE = "DATE";

    public Database(@Nullable Context context) {
        super(context, "workmiles.db", null,1);
    }


    //table creation
    @Override
    public void onCreate(SQLiteDatabase db) {
        /*String CREATE_MILES_TABLE = "CREATE TABLE " + MILES_TABLE + " ("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_MILES + " TEXT, "
                + COLUMN_DATE + " TEXT " + ")";
        db.execSQL(CREATE_MILES_TABLE);*/

        //Create Tables
        String CREATE_LOCATION_TABLE = "CREATE TABLE LOCATION( "
                + "Location_ID INT NOT NULL, "
                + "Street_address VARCHAR(30) NOT NULL, "
                + "City VARCHAR(20) NOT NULL, "
                + "State CHAR(2) NOT NULL, "
                + "Zip_code CHAR(5) NOT NULL, "
                + "PRIMARY KEY(Location_ID));";
        db.execSQL(CREATE_LOCATION_TABLE);

        String CREATE_TRIP_TABLE = "CREATE TABLE TRIP( "
                + "Trip_ID INT NOT NULL, "
                + "Start_date DATE NOT NULL, "
                + "Start_time TIME(0) NOT NULL, "
                + "End_date DATE, "
                + "End_time TIME(0), "
                + "Mileage DECIMAL(6, 2) NOT NULL, "
                + "PRIMARY KEY(Trip_ID));";
        db.execSQL(CREATE_TRIP_TABLE);

        String CREATE_START_LOCATION_TABLE = "CREATE TABLE START_LOCATION( "
                + "Location_ID INT NOT NULL, "
                + "Trip_ID INT NOT NULL, "
                + "PRIMARY KEY(Location_ID, Trip_ID), "
                + "FOREIGN KEY(Location_ID) REFERENCES LOCATION(Location_ID), "
                + "FOREIGN KEY(Trip_ID) REFERENCES TRIP(Trip_ID));";
        db.execSQL(CREATE_START_LOCATION_TABLE);

        String CREATE_END_LOCATION_TABLE = "CREATE TABLE END_LOCATION( "
                + "Location_ID INT NOT NULL, "
                + "Trip_ID INT NOT NULL, "
                + "PRIMARY KEY(Location_ID, Trip_ID), "
                + "FOREIGN KEY(Location_ID) REFERENCES LOCATION(Location_ID), "
                + "FOREIGN KEY(Trip_ID) REFERENCES TRIP(Trip_ID));";
        db.execSQL(CREATE_END_LOCATION_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        onCreate(db);
    }

    //test method of insertion into database
    public boolean addOne(String miles, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_MILES, miles);
        cv.put(COLUMN_DATE, date);

        long insert = db.insert(MILES_TABLE, null, cv);

        if(insert== -1)
        {
            return false;
        }
        else {
            return true;
        }
    }


}
