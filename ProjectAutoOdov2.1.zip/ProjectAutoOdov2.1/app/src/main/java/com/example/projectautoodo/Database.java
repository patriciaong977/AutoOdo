package com.example.projectautoodo;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class Database extends SQLiteOpenHelper
{

    //table strings
    public static final String MILES_TABLE = "MILES_TABLE";
    public static final  String KEY_ID= "ID";
    public static final String COLUMN_MILES = "MILES";
    public static final String COLUMN_DATE = "DATE";

    public Database(@Nullable Context context) {
        super(context, "workmiles.db", null,1);
    }


    //table creation
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_MILES_TABLE = "CREATE TABLE " + MILES_TABLE + " ("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_MILES + " TEXT, "
                + COLUMN_DATE + " TEXT " + ")";
        db.execSQL(CREATE_MILES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        onCreate(db);
    }

    //test method of insertion into database
    public boolean addOne(String miles, String date)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_MILES, miles);
        cv.put(COLUMN_DATE, date);

        long insert = db.insert(MILES_TABLE, null, cv);

        if(insert== -1)
        {
            return false;
        }
        else {
            return true;
        }
    }


}
