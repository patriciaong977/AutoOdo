package com.example.projectautoodo;

//**isha

public class WorkMilesModel
{
    private double workMiles;
    private boolean isActive;

    //Constructors
    public WorkMilesModel(double workMiles, boolean isActive)
    {
        this.workMiles = workMiles;
        this.isActive = isActive;
    }

    public WorkMilesModel()
    {

    }

    //to String for printing contents of a class
    @Override
    public String toString()
    {
        return "WorkMilesModel{" +
                "workMiles=" + workMiles +
                ", isActive=" + isActive +
                '}';
    }

    //Sets and Gets
    public double getWorkMiles()
    {
        return workMiles;
    }

    public void setWorkMiles(double workMiles)
    {
        this.workMiles = workMiles;
    }

    public boolean isActive()
    {
        return isActive;
    }

    public void setActive(boolean active)
    {
        isActive = active;
    }
}

//**isha