package com.example.projectautoodo;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.CalendarView;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity
{

    //**isha
    //References to buttons and other controls
    Button btn_TWM, btn_returnGMI, btn_submit, btn_submitTWM;
    CalendarView calendarView;
    EditText et_inputWM;
    RecyclerView rv_workmilesList;
    //**isha

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //**isha
        btn_TWM = findViewById(R.id.btn_TWM);
        btn_returnGMI = findViewById(R.id.btn_returnGMI);
        btn_submit = findViewById(R.id.btn_submitTWM);
        btn_submitTWM = findViewById(R.id.btn_submitTWM);

        calendarView = findViewById(R.id.calendarView);

        et_inputWM = findViewById(R.id.et_inputWM);

        rv_workmilesList = findViewById(R.id.rv_workmilesList);

        //Button Listener

        //**isha
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}